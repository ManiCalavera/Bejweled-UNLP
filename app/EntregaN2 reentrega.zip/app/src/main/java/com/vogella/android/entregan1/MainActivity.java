package com.vogella.android.entregan1;

import android.graphics.Color;
import android.media.Image;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.SQLOutput;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private GridLayout gridLayout;

    private int[] images = {R.drawable.green, R.drawable.orange, R.drawable.purple, R.drawable.red, R.drawable.yellow, R.drawable.blue};
    private int clicks = 0;
    private int posicionview1, posicionview2;
    private ImageView imageview1, imageview2;
    private TextView textview_puntaje;
    private int i1, i2, j1, j2;
    private int[][] matriz = new int[8][8];
    //private int [][] matrizvertical = new int[8][8];
    private int idimagenclick1 = -2;
    private int idimagenclick2;
    private int cant = -25;
    private int[] aBorrar = new int[64];
    private int sinimagen = -1;
    private int array = 0;
    private int contadorhandler = 0;
    private boolean barridohorizontal = true;
    private boolean barridovertical = true;
    public RegistroViews parametroscontarhuecos = new RegistroViews();
    public RegistroViews parametrosbajarimagen = new RegistroViews();
    private int puntaje = 0;
    private boolean haycoincidencia=false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Inicializar();
        loadviews();

        loadimages();

        haycoincidencia=haycoincidencia();
        limpiartablerodecoincidencias();


        setonclick();


    }


    private void setonclick() {

        for (int i = 0; i < 64; i++) {

            gridLayout.getChildAt(i).setOnClickListener(this);
        }
    }

    private void Inicializar() {
        for (int i = 0; i < 64; i++) {
            aBorrar[i] = -100;
        }
    }

    private boolean barridohorizontal() {
        mostrarMatriz();
        mostrarvectoraBorrar();
        boolean cumple = false;
        int previo = -9;
        int actual = -10;
        int coincidecias = 1;
        int j;

        for (int i = 0; i < 8; i++) {

            for (j = 0; j < 8; j++) {

                actual = matriz[i][j];


                if ((actual != -1) && (actual == previo)) {
                    coincidecias++;
                    previo = actual;
                } else {
                    if (coincidecias > 2) {
                        cumple = true;
                        for (int posicion = j - coincidecias; posicion < j; posicion++) {
                            aBorrar[array] = (i * 8) + posicion;
                            array++;
                        }


                    }

                    previo = actual;

                    coincidecias = 1;


                }


            }

            if (coincidecias > 2) {
                cumple = true;
                for (int posicion = j - coincidecias; posicion < j; posicion++) {
                    aBorrar[array] = (i * 8) + posicion;
                    array++;
                }

            }

            coincidecias = 1;
            previo = -9;


        }

        System.out.println("el barrido horizontal es " + cumple);
        return cumple;
    }


    private boolean barridovertical() {

        boolean cumple = false;
        mostrarMatriz();
        mostrarvectoraBorrar();

        int previo = -9;
        int actual = -10;
        int coincidecias = 1;
        int i;
        for (int j = 0; j < 8; j++) {

            for (i = 0; i < 8; i++) {

                actual = matriz[i][j];


                if ((actual != -1) && (actual == previo)) {

                    coincidecias++;
                    previo = actual;
                    System.out.println(coincidecias + " el actual es " + actual + " el previo es " + previo);

                } else {
                    if (coincidecias > 2) {
                        System.out.println("hay más de dos coincidencias y son " + coincidecias);
                        cumple = true;
                        for (int posicion = i - coincidecias; posicion < i; posicion++) {
                            aBorrar[array] = (posicion * 8) + j;
                            array++;
                        }
                    }


                    previo = actual;

                    coincidecias = 1;


                }


            }

            if (coincidecias > 2) {
                System.out.println("hay más de dos coincidencias y son " + coincidecias);
                cumple = true;
                for (int posicion = i - coincidecias; posicion < i; posicion++) {
                    aBorrar[array] = (posicion * 8) + j;
                    array++;
                }

            }


            coincidecias = 1;
            previo = -9;


        }


        System.out.println("el barrido vertical es" + cumple);
        mostrarMatriz();
        mostrarvectoraBorrar();
        return cumple;
    }


    private void loadviews() {
        gridLayout = findViewById(R.id.Father);
        textview_puntaje = findViewById(R.id.numero);
        textview_puntaje.setText(String.valueOf(puntaje));
    }

    private void loadimages() {
        int randomimage;
        ImageView imageview;

        for (int i = 0; i <= 7; i++) {
            for (int j = 0; j <= 7; j++) {
                randomimage = (int) (Math.random() * 6);
                imageview = (ImageView) gridLayout.getChildAt((i * 8) + j);
                imageview.setImageResource(images[randomimage]);
                imageview.setTag(R.id.j, j);
                imageview.setTag(R.id.i, i);
                imageview.setTag(R.id.imagen, randomimage);
                matriz[i][j] = (randomimage);
            }
        }


    }

    @Override
    public void onClick(View v) {


        clicks++;

        if (clicks == 1) {
            idimagenclick1 = (int) v.getTag(R.id.imagen);
            System.out.println("el click 1 contiene la imagen: " + idimagenclick1);
            imageview1 = (ImageView) v;
            i1 = (int) v.getTag(R.id.i);
            j1 = (int) v.getTag(R.id.j);
            imageview1.setBackgroundColor(Color.RED);

        }
        if (clicks == 2) {
            idimagenclick2 = (int) v.getTag(R.id.imagen);
            System.out.println("el click 1 contiene la imagen: " + idimagenclick2);
            i2 = (int) v.getTag(R.id.i);
            j2 = (int) v.getTag(R.id.j);
            imageview1.setBackgroundColor(Color.TRANSPARENT);


            //si las imágenes son limítrofes

            if ((((j2 - j1 == 1) | (j2 - j1 == -1) && (i2 - i1 == 0))) | (((i1 - i2 == 1) | (i1 - i2 == -1)) && (j1 - j2 == 0))) {

                imageview2 = (ImageView) v;


                matriz[i1][j1] = idimagenclick2;
                matriz[i2][j2] = idimagenclick1;
                System.out.println("Estoy adentro del if limitrofes y los clicks son " + idimagenclick1 + " y " + idimagenclick2);


                //cada barrido me devuelve un boolean que indica si encontró coincidencias
                 haycoincidencia=haycoincidencia();
                if (!haycoincidencia) {   //si el movimiento que se hizo está en rango pero no provoca coincidencias

                    matriz[i1][j1] = idimagenclick1;
                    System.out.println("estoy adentro del if barridos son verdaderos y los clicks son " + idimagenclick1 + " y " + idimagenclick2);

                    Toast.makeText(MainActivity.this, "Ups! movimiento no válido", Toast.LENGTH_SHORT).show();

                } else { //si el movimiento está en rango y provoca coincidencias, se hace el intercambio de imágenes

                    //Hace efectivo el cambio de imágenes
                    imageview1.setImageResource(images[idimagenclick2]);
                    imageview1.setTag(R.id.imagen, idimagenclick2);
                    imageview2.setImageResource(images[idimagenclick1]);
                    imageview2.setTag(R.id.imagen, idimagenclick1);
                    System.out.println("cambie las imagenes y los clicks son + " + idimagenclick1 + " y " + idimagenclick2);

                    limpiartablerodecoincidencias();


                }
            } else { //el movimiento que se hizo no está en rango
                Toast.makeText(MainActivity.this, "Ups! movimiento no válido", Toast.LENGTH_SHORT).show();
            }
            matriz[i2][j2] = idimagenclick2;
            clicks = 0;

        }
    }


    private void mostrarMatriz() {
        System.out.println("enter");

        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                System.out.print("       " + matriz[i][j] + "       ");
            }
            System.out.println();
        }
        System.out.println("enter");

    }

    private void mostrarvectoraBorrar() {
        System.out.println("ESTE ES EL VECTOR CON POSCICIONES A BORRAR");
        for (int i = 0; i < 64; i++) {

            System.out.println("   " + aBorrar[i]);
        }
    }


    //necesitamos la pos en donde borrar , cada vez que se la llama , la pos se vuelve 0;
    private void turninvisible() {
        ImageView imagen;

        int i;
        int j;

        //Posiciono la variable acumuladora de invisibles en la última posición usada
        if (array > 0) {
            array--;
        }

        if ((array >= 0) && (aBorrar[array] != -100)) {

            puntaje += array+1;
            textview_puntaje.setText(String.valueOf(puntaje));

            for (int k = array; k >= 0; k--) {
                imagen = (ImageView) gridLayout.getChildAt(aBorrar[k]);
                imagen.setAlpha(0.5f);
                i = (int) imagen.getTag(R.id.i);
                j = (int) imagen.getTag(R.id.j);

                matriz[i][j] = -1;
                aBorrar[k] = -100;


            }
        }
        array = 0;
        mostrarvectoraBorrar();
        mostrarMatriz();


    }


    private RegistroViews contarhuecos(int i_hueco, int j) {

        int cant = 0;


        //I_hueco va a almacenar la posición del primer hueco que encuentre, si lo hay.
        //Me  fijo si hay huecos
        while ((i_hueco >= 0) && (matriz[i_hueco][j] != -1)) {
            i_hueco--;
        }

        // i_imagen es la variable que va a almacenar la primera posición luego de los huecos. Puede ser una imagen o puede que se salga de la matriz
        int i_imagen = i_hueco;
        //Cuento los huecos
        if (i_hueco >= 0) {
            while ((i_imagen >= 0) && (matriz[i_imagen][j] == -1)) {
                i_imagen--;
                cant++;
            }

        }


        return new RegistroViews(i_imagen, i_hueco, cant);

    }


    //borrar
    private boolean hayImagenArriba(int i, int j) {


        return ((i >= 0) && (matriz[i][j] != -1));
    }

    private int contarimagenesentodalacolumna(int i, int j) {
        int cant = 0;
        while (i >= 0) {
            if (matriz[i][j] != -1) {
                cant++;

            }
            i--;
        }
        return cant;
    }

    private int contarimagenes(int i, int j) {
        int cant = 0;
        while ((i >= 0) && (matriz[i][j] != -1)) {
            i--;
            cant++;
        }
        return cant;
    }


    private RegistroViews bajarimagenes(int i_hueco, int i_imagen, int j, int canthuecos, int cantimagenes) {

        ImageView image;


        while ((canthuecos != 0) && (cantimagenes != 0)) {


            //Bajo la imagen y actualizo la matriz en el hueco
            matriz[i_hueco][j] = matriz[i_imagen][j];


            //Actualizo la imagen en la View y la visibilizo
            image = (ImageView) gridLayout.getChildAt((i_hueco * 8) + j);
            image.setImageResource(images[matriz[i_imagen][j]]);
            image.setTag(R.id.imagen, matriz[i_imagen][j]);
            image.setAlpha(1f);

            //Invisibilizo la view a la que le acabo de sacar la imagen
            image = (ImageView) gridLayout.getChildAt(((i_imagen) * 8) + j);
            image.setAlpha(0.5f);

            //Actualizo la matriz en la imagen
            matriz[i_imagen][j] = -1;


            //Actualizo cantidad de huecos para quizás después hacer un return y utilizarlo para rellenar con imágenes random
            canthuecos--;

            //reduzco la cantidad de imagenes para estar seguro de las imagenes que tengo que bajar
            cantimagenes--;


            //Actualizo la posición del hueco a reemplazar y la imagen a sustituir
            i_hueco--;
            i_imagen--;

        }
        mostrarMatriz();
        return new RegistroViews(i_imagen, i_hueco);


    }

    public void crearImagenes(int i, int j) {
        int randomimage;
        ImageView imageview;
        for (int k = i; k >= 0; k--) {
            if (matriz[k][j] == -1) {

                //Creo imagenes nuevas, actualizo y visibilizo
                randomimage = (int) (Math.random() * 6);
                imageview = (ImageView) gridLayout.getChildAt((k * 8) + j);
                imageview.setImageResource(images[randomimage]);
                imageview.setTag(R.id.imagen, randomimage);
                imageview.setAlpha(1f);


                //Pego la imagen nueva en matriz
                matriz[k][j] = randomimage;
            }


        }


    }

    private void bajarycrearImagenes() {

        int canthuecos;
        int cantimagenes = 0;
        int i_imagen;
        int i_hueco;

        for (int j = 7; j >= 0; j--) {

            parametroscontarhuecos = contarhuecos(7, j);
            canthuecos = parametroscontarhuecos.getCanthuecos();
            i_imagen = parametroscontarhuecos.getI_imagen();
            i_hueco = parametroscontarhuecos.getI_hueco();

            if (canthuecos != 0) {
                if (hayImagenArriba(i_imagen, j)) {
                    cantimagenes = contarimagenes(i_imagen, j);
                    parametrosbajarimagen = bajarimagenes(i_hueco, i_imagen, j, canthuecos, cantimagenes);
                    cantimagenes = contarimagenesentodalacolumna(parametrosbajarimagen.getI_imagen(), j);


                    while (cantimagenes > 0) {
                        parametroscontarhuecos = contarhuecos(parametrosbajarimagen.getI_hueco(), j);
                        canthuecos = parametroscontarhuecos.getCanthuecos();
                        i_imagen = parametroscontarhuecos.getI_imagen();
                        i_hueco = parametroscontarhuecos.getI_hueco();
                        parametrosbajarimagen = bajarimagenes(i_hueco, i_imagen, j, canthuecos, contarimagenes(i_imagen, j));
                        cantimagenes = contarimagenesentodalacolumna(parametrosbajarimagen.getI_imagen(), j);
                    }

                    crearImagenes(parametrosbajarimagen.getI_hueco(), j);


                } else {
                    crearImagenes(i_hueco, j);
                }

                //Relleno con imágenes random


                //acá podría rellenar los huecos que quedaron con imágenes nuevas

            }


        }

        mostrarMatriz();


    }


    private void limpiartablerodecoincidencias() {


        final Handler handler = new Handler();








            handler.postDelayed(new Runnable() {
                @Override


                public void run() {


                        if (MainActivity.this.contadorhandler ==0) {
                            if (haycoincidencia) {


                                turninvisible();


                            }
                            contadorhandler++;
                            handler.postDelayed(this,500);

                        }

                        else {
                            if (contadorhandler ==1) {

                                MainActivity.this.bajarycrearImagenes();
                                contadorhandler++;
                                handler.postDelayed(this,500);

                            }

                            else {
                                contadorhandler = 0;
                                haycoincidencia=haycoincidencia();
                                if (haycoincidencia) {
                                    handler.postDelayed(this, 500);
                                }

                            }


                        }




                }
            }, 500);
        }


        private boolean haycoincidencia () {
            return ((barridohorizontal())| (barridovertical()));

        }



    }



