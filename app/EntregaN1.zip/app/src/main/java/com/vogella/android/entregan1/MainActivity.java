package com.vogella.android.entregan1;

import android.media.Image;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.Toast;

import java.sql.SQLOutput;
import java.util.Random;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private GridLayout gridLayout;
    private RegistroViews matriz[][] = new RegistroViews[8][8];
    private int[] images = {R.drawable.green, R.drawable.orange, R.drawable.purple, R.drawable.red, R.drawable.yellow, R.drawable.blue};
    private int clicks = 0;
    private int posicionview1, posicionview2 ;
    private ImageView imageview1, imageview2;
    private boolean barridohorizontal =  false;
    private boolean barridovertical = false;
    int imagenauxiliar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);




        loadviews();

        loadimages();

        barridohorizontal();

        barridovertical();

        turninvisible(matriz);

        setonclick();


    }


    private void setonclick () {

        for (int i= 0; i <64; i++){

            gridLayout.getChildAt(i).setOnClickListener(this);
        }
    }

    private boolean barridohorizontal() {

        boolean cumple = false;

        for (int i = 0; i <= 7; i++) {
            for (int j = 0; j <= 7; j++) {
                System.out.print((matriz[i][j])+ "      ");
            }
            System.out.println();
        }
        int previo = -9;
        int actual = -10;
        int coincidecias = 1;
        int j;

        for (int i = 0; i < 8; i++) {

            for (j = 0; j < 8; j++) {

                actual = matriz [i] [j];



                if (actual == previo) {
                    coincidecias++;
                    previo = actual;
                } else {
                    if (coincidecias > 2) {
                        cumple = true;
                        for (int posicion = j - coincidecias; posicion < j; posicion++) {
                            matriz[i][posicion] = -1;
                            gridLayout.getChildAt((i* 8)+ posicion).setVisibility(View.INVISIBLE);

                        }

                        previo = -9;
                    } else {
                        previo = actual;
                    }
                    coincidecias = 1;


                }


            }

            if (coincidecias > 2) {
                cumple = true;
                for (int posicion = j - coincidecias; posicion < j; posicion++) {
                    matriz[i][posicion] = -1;
                    gridLayout.getChildAt((i* 8)+ posicion).setVisibility(View.INVISIBLE);
                }

            }

            coincidecias = 1;
            previo = -9;


        }

        return cumple;
    }


    private boolean barridovertical() {

        boolean cumple = false;

        /*for (int i = 0; i <= 7; i++) {
            for (int j = 0; j <= 7; j++) {
                System.out.print((matriz[i][j])+ "  ");
            }
            System.out.println();
        }
        */
        int previo = -9;
        int actual = -10;
        int coincidecias = 1;
        int j;

        for (int i = 0; i < 8; i++) {

            for (j = 0; j < 8; j++) {

                actual = matriz [j] [i];



                if (actual == previo) {
                    coincidecias++;
                    previo = actual;
                } else {
                    if (coincidecias > 2) {
                        cumple = true;
                        for (int posicion = j - coincidecias; posicion < j; posicion++) {
                            matriz[posicion][i] = -1;
                            gridLayout.getChildAt((i* 8)+ posicion).setVisibility(View.INVISIBLE);

                        }

                        previo = -9;
                    } else {
                        previo = actual;
                    }
                    coincidecias = 1;


                }


            }

            if (coincidecias > 2) {
                cumple = true;
                for (int posicion = j - coincidecias; posicion < j; posicion++) {
                    matriz[posicion][i] = -1;
                }

            }



            coincidecias = 1;
            previo = -9;


        }
        /*
        for (int i = 0; i <= 7; i++) {
            for (j = 0; j <= 7; j++) {
                System.out.print((matriz[i][j])+ "  ");
            }
            System.out.println();
        }
        */

        return  cumple;
    }


        private void loadviews () {
            gridLayout = findViewById(R.id.Father);
        }

        private void loadimages () {
            int randomimage;
            ImageView imageview;

            for (int i = 0; i <= 7; i++) {
                for (int j = 0; j <= 7; j++) {
                    randomimage = (int) (Math.random() * 6);
                    imageview = (ImageView) gridLayout.getChildAt((i * 8) + j);
                    imageview.setImageResource(images[randomimage]);
                    imageview.setTag(R.id.j, j);
                    imageview.setTag(R.id.i, i);
                    matriz[i][j] = new int (randomimage);
                }
            }

        }

    @Override
    public void onClick(View v) {
        clicks ++;

        if (clicks == 1) {
            posicionview1 = (int)v.getTag();
            imageview1 = (ImageView) v;
        }
        if (clicks == 2) {
            posicionview2 = (int) v.getTag();
            if ((posicionview2 - posicionview1 == 1) | (posicionview2 - posicionview1 == -1) | (posicionview2 - posicionview1 == 8) | (posicionview2 - posicionview1 == -8)) {
                imageview2 = (ImageView) v;
                imagenauxiliar = matriz [(posicionview2 / 8)] [ posicionview2 % 8];
                imagenauxiliar2 =
                matriz [(posicionview2 / 8)] [ posicionview2 % 8] =  matriz [(posicionview1 / 8)] [ posicionview1 % 8];
                matriz [(posicionview1 / 8)] [ posicionview1 % 8] =  imagenauxiliar;
                barridohorizontal = barridohorizontal();
                barridovertical = barridovertical();
                if ((!barridohorizontal) && (!barridovertical)) {
                    matriz [(posicionview1 / 8)] [ posicionview1 % 8] =  matriz [(posicionview2 / 8)] [ posicionview2 % 8];
                    matriz [(posicionview2 / 8)] [ posicionview2 % 8] = imagenauxiliar;
                }

                else {
                    imageview1.setImageResource(images [imagenauxiliar]);
                    imageview2.setImageResource(images[matriz[(posicionview1 / 8)][posicionview1 % 8]]);
                    turninvisible(matriz);
                }
            }

            else {
                    Toast.makeText(MainActivity.this, "Ups! movimiento no válido", Toast.LENGTH_SHORT).show();
            }
            clicks = 0;

        }
    }


    private void turninvisible (RegistroViews matrizcopia [][]) {
        for (int i= 0; i < 8; i++){
            for (int j = 0; j <8; j++) {
                if (matrizcopia [i] [j].getImage() == -1) {
                    gridLayout.getChildAt((i * 8) + j).setVisibility(View.INVISIBLE);
                }
            }

        }
    }
}


